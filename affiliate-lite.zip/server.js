/**
 * Simple Affiliate System - Express + MongoDB
 * Signup requires ONLY: name + walletAddress
 * Endpoints:
 *  POST /api/signup {name,walletAddress}
 *  POST /api/login  {walletAddress}
 *  GET  /api/me     (auth)
 *  GET  /api/stats  (auth)
 *  GET  /r/:code    (tracks click -> redirects)
 */
require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const cors = require("cors");
const mongoose = require("mongoose");
const jwt = require("jsonwebtoken");
const { customAlphabet } = require("nanoid");
const User = require("./models/User");
const Click = require("./models/Click");

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || "dev-secret-change-me";
const BASE_URL = process.env.BASE_URL || `http://localhost:${PORT}`;
const REDIRECT_URL = process.env.REDIRECT_URL || `${BASE_URL}/public/thanks.html`;
const AFF_LEN = parseInt(process.env.AFF_LEN || "9", 10);
const nanoid = customAlphabet("0123456789abcdefghijklmnopqrstuvwxyz", AFF_LEN);

/* -------------------- MIDDLEWARE -------------------- */
app.use(helmet());
app.use(express.json());
app.use("/public", express.static("public"));

// Request logger
app.use((req, _res, next) => {
  console.log(`[REQ] ${req.method} ${req.originalUrl} from ${req.headers.origin || "unknown"}`);
  next();
});

/* -------------------- CORS (localhost + prod) -------------------- */
const allowedOrigins = [
  "http://localhost:5173",
  "http://127.0.0.1:5173",
  process.env.FRONTEND_ORIGIN || "" // e.g., https://your-frontend.example.com
].filter(Boolean);

app.use((req, res, next) => {
  const origin = req.headers.origin;
  if (!origin || allowedOrigins.includes(origin)) {
    if (origin) res.header("Access-Control-Allow-Origin", origin);
    else res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods", "GET,POST,PUT,PATCH,DELETE,OPTIONS");
    res.header("Access-Control-Allow-Headers", "Content-Type,Authorization");
    res.header("Access-Control-Allow-Credentials", "true");
    if (req.method === "OPTIONS") return res.sendStatus(204);
    return next();
  }
  console.warn(`🚫 CORS blocked from: ${origin}`);
  return res.status(403).json({ error: "CORS blocked" });
});

/* -------------------- MONGO -------------------- */
const MONGODB_URI = process.env.MONGODB_URI || "mongodb://127.0.0.1:27017/affiliate_mongo";
mongoose.connect(MONGODB_URI).then(() => {
  console.log("✅ Mongo connected");
}).catch((err) => {
  console.error("❌ Mongo error:", err.message);
  process.exit(1);
});

/* -------------------- AUTH -------------------- */
function signJWT(u) {
  return jwt.sign({ uid: u._id.toString() }, JWT_SECRET, { expiresIn: "7d" });
}
function auth(req, res, next) {
  const h = req.headers.authorization || "";
  const token = h.startsWith("Bearer ") ? h.slice(7) : null;
  if (!token) return res.status(401).json({ error: "missing token" });
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({ error: "invalid token" });
  }
}

/* -------------------- ROUTES -------------------- */
app.get("/api/test", (_req, res) => res.json({ ok: true }));

// Signup: ONLY name + walletAddress
app.post("/api/signup", async (req, res) => {
  try {
    const { name, walletAddress } = req.body || {};
    if (!name || !walletAddress) {
      return res.status(400).json({ error: "name and walletAddress are required" });
    }

    const existing = await User.findOne({ walletAddress: walletAddress.trim() });
    if (existing) return res.status(409).json({ error: "wallet already registered" });

    let affiliateCode;
    while (true) {
      affiliateCode = nanoid();
      const dup = await User.findOne({ affiliateCode });
      if (!dup) break;
    }
    const affiliateLink = `${BASE_URL}/r/${affiliateCode}`;

    const user = await User.create({
      name: name.trim(),
      walletAddress: walletAddress.trim(),
      affiliateCode,
      affiliateLink
    });

    const token = signJWT(user);
    return res.json({
      user: {
        id: user._id,
        name: user.name,
        walletAddress: user.walletAddress,
        affiliateCode: user.affiliateCode,
        affiliateLink: user.affiliateLink,
        createdAt: user.createdAt,
      },
      token,
    });
  } catch (err) {
    console.error("Signup error:", err);
    res.status(500).json({ error: "server error" });
  }
});

// Login: by walletAddress only (no password)
app.post("/api/login", async (req, res) => {
  try {
    const { walletAddress } = req.body || {};
    if (!walletAddress) return res.status(400).json({ error: "walletAddress required" });
    const user = await User.findOne({ walletAddress: walletAddress.trim() });
    if (!user) return res.status(404).json({ error: "user not found" });
    const token = signJWT(user);
    return res.json({
      user: {
        id: user._id,
        name: user.name,
        walletAddress: user.walletAddress,
        affiliateCode: user.affiliateCode,
        affiliateLink: user.affiliateLink,
        createdAt: user.createdAt,
      },
      token,
    });
  } catch (err) {
    console.error("Login error:", err);
    res.status(500).json({ error: "server error" });
  }
});

// Me
app.get("/api/me", auth, async (req, res) => {
  const user = await User.findById(req.user.uid).select("name walletAddress affiliateCode affiliateLink createdAt");
  res.json({ user });
});

// Stats
app.get("/api/stats", auth, async (req, res) => {
  const uid = req.user.uid;
  const [total, uniqueAgg, byDay] = await Promise.all([
    Click.countDocuments({ userId: uid }),
    Click.aggregate([
      { $match: { userId: new mongoose.Types.ObjectId(uid) } },
      { $group: { _id: "$ip" } },
      { $count: "unique" },
    ]),
    Click.aggregate([
      { $match: { userId: new mongoose.Types.ObjectId(uid) } },
      { $group: { _id: { $substr: ["$createdAt", 0, 10] }, c: { $sum: 1 } } },
      { $project: { day: "$_id", c: 1, _id: 0 } },
      { $sort: { day: 1 } },
    ]),
  ]);
  const unique = uniqueAgg.length ? uniqueAgg[0].unique : 0;
  res.json({ totalClicks: total, uniqueClicks: unique, clicksByDay: byDay });
});

// Redirect / track
app.get("/r/:code", async (req, res) => {
  const { code } = req.params;
  const user = await User.findOne({ affiliateCode: code }).select("_id");
  if (!user) return res.status(404).send("Unknown affiliate link");

  const ip = (req.headers["x-forwarded-for"]?.split(",")[0] || req.socket.remoteAddress || "").toString();
  const ua = req.headers["user-agent"] || "";
  const ref = req.headers["referer"] || req.headers["referrer"] || "";
  await Click.create({ userId: user._id, affiliateCode: code, ip, userAgent: ua, referrer: ref });

  res.redirect(302, REDIRECT_URL);
});

app.get("/", (_req, res) => res.redirect("/public/index.html"));

/* -------------------- START -------------------- */
app.listen(PORT, () => console.log(`🚀 Affiliate system running on ${BASE_URL}`));
